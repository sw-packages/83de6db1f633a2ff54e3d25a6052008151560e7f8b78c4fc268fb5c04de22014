#ifndef XML_MEMORY_H_PRIVATE__
#define XML_MEMORY_H_PRIVATE__

XML_HIDDEN void
xmlInitMemoryInternal(void);
XML_HIDDEN void
xmlCleanupMemoryInternal(void);

#endif /* XML_MEMORY_H_PRIVATE__ */
